package lr1;

public class Example2 {
    public static void main(String[] args) {
        int num = 100;
        System.out.println("num: " + num);
        num = num * 2;
        System.out.println("num * 2 = " + num);
    }
}
